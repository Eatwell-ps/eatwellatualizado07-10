
EatWell

 Integrantes do Grupo

- Pablo Daniel – 22300546
- Andre Henrique – 22300686
- Eduardo Oliveira – 12302767
- Thiago fonseca – 

**Turma:3C2** 3º Semestre - Desenvolvimento de Sistemas

---

 Funcionalidades - Terceira Entrega

Checklist de funcionalidades com status atual:

- [x]  Cadastro de usuários
- [x]  Redefinição de senha
- [x]  Notificações de lembrete

- [x]  D-Histórico de atividades
- [x]  D-Alerta de hidratação
- [x]  D-Personalização da interface

- [x]  Busca de alimentos por dieta

- [x]  T-Gráficos de consumo e massa muscular
- [x]  T-Suporte para nutricionistas e especialistas
- [x]  T-Planejamento de refeições
- [x]  T-Substituições saudáveis
- [x]  T-Sistema de recompensas
 
- [x]  Alerta de não cumprimento alimentar
- [x]  Sugestões de alimentos personalizados
- [x]  Análise de sustentabilidade alimentar
- [x]  Apoio a hábitos e dietas específicos